/*
# Lock app_state to authenticated users only

1. Purpose
   - The app now requires login (single super-user: admin).
   - Previously RLS allowed anon access; now we restrict to authenticated only
     so unauthenticated visitors cannot read or write data.

2. Security changes
   - Drop all existing anon+authenticated policies on app_state.
   - Create new policies scoped TO authenticated only, with USING(true) since
     there is only one super-user and all data belongs to them.

3. Notes
   - The admin user is created via Supabase auth (email/password).
   - No schema changes, no data loss.
*/

DROP POLICY IF EXISTS "anon_select_app_state" ON app_state;
DROP POLICY IF EXISTS "anon_insert_app_state" ON app_state;
DROP POLICY IF EXISTS "anon_update_app_state" ON app_state;
DROP POLICY IF EXISTS "anon_delete_app_state" ON app_state;

CREATE POLICY "auth_select_app_state" ON app_state FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "auth_insert_app_state" ON app_state FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_app_state" ON app_state FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_app_state" ON app_state FOR DELETE
  TO authenticated USING (true);
