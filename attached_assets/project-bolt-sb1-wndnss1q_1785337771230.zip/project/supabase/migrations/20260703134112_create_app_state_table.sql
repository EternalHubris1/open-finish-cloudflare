/*
# Create app_state table for cloud sync (single-tenant, no auth)

1. Purpose
   - Stores the user's full app state (habits, deadlines, progress) in the cloud
     so it syncs across devices when the app is opened.
   - Single-tenant design: no user_id, no sign-in. The app uses a device-generated
     profile_id (UUID stored in localStorage) to identify a unique data set.
     This lets the same anon-key client manage multiple isolated profiles if needed,
     and keeps data private per profile without requiring authentication.

2. New Tables
   - `app_state`
     - `id` (uuid, primary key, defaults to gen_random_uuid())
     - `profile_id` (text, not null) — identifies a unique data set (generated client-side)
     - `habits` (jsonb) — array of habit definitions
     - `deadlines` (jsonb) — array of deadline objects
     - `progress` (jsonb) — map of dateKey -> { habitKey: boolean, hours: number }
     - `updated_at` (timestamptz, defaults to now()) — last sync time

3. Indexes
   - Unique index on `profile_id` so each profile has exactly one row (upsert pattern).

4. Security
   - Enable RLS on `app_state`.
   - Allow anon + authenticated full CRUD (single-tenant, no auth — data is scoped
     by profile_id which the client generates and manages).
   - Policies use `USING (true)` because there is no user ownership concept;
     isolation is by profile_id, which the client controls.

5. Notes
   - The frontend uses upsert (INSERT ... ON CONFLICT UPDATE) to sync state.
   - profile_id is generated as a UUID v4 on first load and stored in localStorage.
*/

CREATE TABLE IF NOT EXISTS app_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id text NOT NULL,
  habits jsonb DEFAULT '[]'::jsonb,
  deadlines jsonb DEFAULT '[]'::jsonb,
  progress jsonb DEFAULT '{}'::jsonb,
  updated_at timestamptz DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS app_state_profile_id_idx ON app_state (profile_id);

ALTER TABLE app_state ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_app_state" ON app_state;
CREATE POLICY "anon_select_app_state" ON app_state FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_app_state" ON app_state;
CREATE POLICY "anon_insert_app_state" ON app_state FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_app_state" ON app_state;
CREATE POLICY "anon_update_app_state" ON app_state FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_app_state" ON app_state;
CREATE POLICY "anon_delete_app_state" ON app_state FOR DELETE
  TO anon, authenticated USING (true);
