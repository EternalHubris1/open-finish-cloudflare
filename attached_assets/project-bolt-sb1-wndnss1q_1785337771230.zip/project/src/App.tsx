import HabitTracker from './HabitTracker';
import LoginScreen from './LoginScreen';
import { useAuth } from './useAuth';

export default function App() {
  const { session, loading, signIn, signOut } = useAuth();

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 40%, #16161d 70%, #0f0f0f 100%)' }}
      >
        <div className="text-white/40 text-sm animate-pulse">Загрузка...</div>
      </div>
    );
  }

  if (!session) {
    return (
      <LoginScreen
        onSignIn={async (username, password) => {
          const { error } = await signIn(username, password);
          return { error: error ? error.message : null };
        }}
      />
    );
  }

  return <HabitTracker onSignOut={signOut} />;
}
