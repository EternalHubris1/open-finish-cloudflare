import { useState, useEffect, useCallback, useRef } from 'react';
import { Flag, ListTodo, Trophy, Flame, Star, Sparkles, Clock, History, ChevronDown, User, LogOut } from 'lucide-react';
import HabitsModal from './HabitsModal';
import DeadlinesModal from './DeadlinesModal';
import AchievementsModal from './AchievementsModal';
import StreakHistoryModal from './StreakHistoryModal';
import { useCloudSync } from './useCloudSync';
import { Habit, Deadline, Progress, Achievement, StreakMilestone } from './types';

const DEFAULT_HABITS: Habit[] = [
  { key: 'stats', label: '📊 Статистика', reason: 'Основа для анализа данных и ML', enabled: true },
  { key: 'python', label: '🐍 Python', reason: 'Главный инструмент дата-сайентиста', enabled: true },
  { key: 'sql', label: '🗄️ SQL', reason: 'Работа с базами данных каждый день', enabled: true },
];

const ALL_ACHIEVEMENTS: Achievement[] = [
  { id: 'first_day', name: 'Первый шаг', description: 'Выполните все задачи за один день', icon: 'star', category: 'special', requirement: 1 },
  { id: 'streak_3', name: 'Разогрев', description: 'Серия 3 дня подряд', icon: 'flame', category: 'streak', requirement: 3 },
  { id: 'streak_7', name: 'Недельный воин', description: 'Серия 7 дней подряд', icon: 'flame', category: 'streak', requirement: 7 },
  { id: 'streak_14', name: 'Две недели силы', description: 'Серия 14 дней подряд', icon: 'flame', category: 'streak', requirement: 14 },
  { id: 'streak_30', name: 'Месяц дисциплины', description: 'Серия 30 дней подряд', icon: 'trophy', category: 'streak', requirement: 30 },
  { id: 'streak_60', name: 'Мастер привычки', description: 'Серия 60 дней подряд', icon: 'crown', category: 'streak', requirement: 60 },
  { id: 'streak_100', name: 'Легенда', description: 'Серия 100 дней подряд', icon: 'crown', category: 'streak', requirement: 100 },
  { id: 'xp_50', name: 'Новичок', description: 'Наберите 50 XP', icon: 'zap', category: 'xp', requirement: 50 },
  { id: 'xp_100', name: 'Ученик', description: 'Наберите 100 XP', icon: 'zap', category: 'xp', requirement: 100 },
  { id: 'xp_250', name: 'Исследователь', description: 'Наберите 250 XP', icon: 'medal', category: 'xp', requirement: 250 },
  { id: 'xp_500', name: 'Эксперт', description: 'Наберите 500 XP', icon: 'trophy', category: 'xp', requirement: 500 },
  { id: 'xp_1000', name: 'Мастер', description: 'Наберите 1000 XP', icon: 'crown', category: 'xp', requirement: 1000 },
  { id: 'level_5', name: 'Рост', description: 'Достигните уровня 5', icon: 'star', category: 'level', requirement: 5 },
  { id: 'level_10', name: 'Прогресс', description: 'Достигните уровня 10', icon: 'star', category: 'level', requirement: 10 },
  { id: 'level_20', name: 'Подъем', description: 'Достигните уровня 20', icon: 'medal', category: 'level', requirement: 20 },
  { id: 'level_50', name: 'Величие', description: 'Достигните уровня 50', icon: 'crown', category: 'level', requirement: 50 },
  { id: 'perfect_10', name: 'Десяточка', description: '10 идеальных дней', icon: 'target', category: 'special', requirement: 10 },
  { id: 'perfect_50', name: 'Половина сотни', description: '50 идеальных дней', icon: 'medal', category: 'special', requirement: 50 },
  { id: 'perfect_100', name: 'Сотня', description: '100 идеальных дней', icon: 'trophy', category: 'special', requirement: 100 },
];

const STREAK_MILESTONES: StreakMilestone[] = [
  { days: 7, reward: 'Неделя', xpBonus: 10, unlocked: false },
  { days: 14, reward: '2 недели', xpBonus: 25, unlocked: false },
  { days: 30, reward: 'Месяц', xpBonus: 50, unlocked: false },
  { days: 60, reward: '2 месяца', xpBonus: 100, unlocked: false },
];

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export default function HabitTracker({ onSignOut }: { onSignOut: () => void }) {
  const today = new Date();
  const todayKey = today.toISOString().split('T')[0];

  const [habits, setHabits] = useState<Habit[]>(() => load('habit-habits', DEFAULT_HABITS));
  const [deadlines, setDeadlines] = useState<Deadline[]>(() => load('habit-deadlines', []));
  const [progress, setProgress] = useState<Progress>(() => load('habit-progress', {}));
  const [statusText, setStatusText] = useState<string>(() => load('habit-status', ''));
  const [showHabits, setShowHabits] = useState(false);
  const [showDeadlines, setShowDeadlines] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [newAchievements, setNewAchievements] = useState<Achievement[]>([]);
  const [streakBonus, setStreakBonus] = useState<{ days: number; xp: number } | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<number>(today.getMonth());
  const [monthDropdownOpen, setMonthDropdownOpen] = useState(false);
  const monthDropdownRef = useRef<HTMLDivElement>(null);

  const activeHabits = habits.filter((h) => h.enabled);

  useEffect(() => { localStorage.setItem('habit-habits', JSON.stringify(habits)); }, [habits]);
  useEffect(() => { localStorage.setItem('habit-deadlines', JSON.stringify(deadlines)); }, [deadlines]);
  useEffect(() => { localStorage.setItem('habit-progress', JSON.stringify(progress)); }, [progress]);
  useEffect(() => { localStorage.setItem('habit-status', JSON.stringify(statusText)); }, [statusText]);

  useCloudSync({
    habits,
    deadlines,
    progress,
    status: statusText,
    setHabits,
    setDeadlines,
    setProgress,
    setStatus: setStatusText,
    isAuthenticated: true,
  });

  // Start from the earliest date with any logged progress, or Jan 1 if none
  const startDate = (() => {
    const keys = Object.keys(progress).sort();
    if (keys.length > 0) {
      const earliest = new Date(keys[0]);
      // Don't go before Jan 1 of the current year
      const jan1 = new Date(today.getFullYear(), 0, 1);
      return earliest < jan1 ? jan1 : earliest;
    }
    return new Date(today.getFullYear(), 0, 1);
  })();

  const endDate = new Date(today.getFullYear(), 11, 31);

  const generateDates = () => {
    const dates: Date[] = [];
    const current = new Date(startDate);
    while (current <= endDate) {
      dates.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    return dates;
  };

  const dates = generateDates();

  const formatDateKey = (date: Date) => date.toISOString().split('T')[0];

  const deadlineSet = new Set(deadlines.map((d) => d.date));
  const deadlineMap = new Map(deadlines.map((d) => [d.date, d.label]));

  const getCompletedCount = useCallback((dateKey: string) => {
    const day = progress[dateKey]?.habits || {};
    const completed = activeHabits.filter((h) => day[h.key]).length;
    const total = activeHabits.length;
    return total === 0 ? 0 : completed;
  }, [progress, activeHabits]);

  const calculateXP = useCallback(() => {
    let total = 0;
    Object.values(progress).forEach((day) => {
      Object.values(day.habits || {}).forEach((v) => { if (v) total += 1; });
    });
    return total;
  }, [progress]);

  const calculateStreak = useCallback(() => {
    let streak = 0;
    const sorted = [...dates].sort((a, b) => b.getTime() - a.getTime());
    for (const date of sorted) {
      const key = formatDateKey(date);
      const total = activeHabits.length;
      if (total > 0 && getCompletedCount(key) === total) streak += 1;
      else break;
    }
    return streak;
  }, [dates, activeHabits, getCompletedCount]);

  const calculateLongestStreak = useCallback(() => {
    let longest = 0;
    let current = 0;
    const sorted = [...dates].sort((a, b) => a.getTime() - b.getTime());
    for (const date of sorted) {
      const key = formatDateKey(date);
      const total = activeHabits.length;
      if (total > 0 && getCompletedCount(key) === total) {
        current += 1;
        if (current > longest) longest = current;
      } else {
        current = 0;
      }
    }
    return longest;
  }, [dates, activeHabits, getCompletedCount]);

  const calculatePerfectDays = useCallback(() => {
    let count = 0;
    for (const date of dates) {
      const key = formatDateKey(date);
      const total = activeHabits.length;
      if (total > 0 && getCompletedCount(key) === total) count += 1;
    }
    return count;
  }, [dates, activeHabits, getCompletedCount]);

  const calculateTotalTasks = useCallback(() => {
    let total = 0;
    Object.values(progress).forEach((day) => {
      Object.values(day.habits || {}).forEach((v) => { if (v) total += 1; });
    });
    return total;
  }, [progress]);

  const xp = calculateXP();
  const level = Math.floor(xp / 15) + 1;
  const streak = calculateStreak();
  const longestStreak = calculateLongestStreak();
  const perfectDays = calculatePerfectDays();
  const totalTasks = calculateTotalTasks();

  const unlockedAchievementIds = new Set<string>();

  if (perfectDays >= 1) unlockedAchievementIds.add('first_day');
  if (streak >= 3) unlockedAchievementIds.add('streak_3');
  if (streak >= 7) unlockedAchievementIds.add('streak_7');
  if (streak >= 14) unlockedAchievementIds.add('streak_14');
  if (streak >= 30) unlockedAchievementIds.add('streak_30');
  if (streak >= 60) unlockedAchievementIds.add('streak_60');
  if (streak >= 100) unlockedAchievementIds.add('streak_100');
  if (xp >= 50) unlockedAchievementIds.add('xp_50');
  if (xp >= 100) unlockedAchievementIds.add('xp_100');
  if (xp >= 250) unlockedAchievementIds.add('xp_250');
  if (xp >= 500) unlockedAchievementIds.add('xp_500');
  if (xp >= 1000) unlockedAchievementIds.add('xp_1000');
  if (level >= 5) unlockedAchievementIds.add('level_5');
  if (level >= 10) unlockedAchievementIds.add('level_10');
  if (level >= 20) unlockedAchievementIds.add('level_20');
  if (level >= 50) unlockedAchievementIds.add('level_50');
  if (perfectDays >= 10) unlockedAchievementIds.add('perfect_10');
  if (perfectDays >= 50) unlockedAchievementIds.add('perfect_50');
  if (perfectDays >= 100) unlockedAchievementIds.add('perfect_100');

  const achievements = ALL_ACHIEVEMENTS.map((a) => ({
    ...a,
    unlockedAt: unlockedAchievementIds.has(a.id) ? todayKey : undefined,
  }));

  const streakMilestones = STREAK_MILESTONES.map((m) => ({
    ...m,
    unlocked: streak >= m.days,
  }));

  const totalAchievements = achievements.filter((a) => a.unlockedAt).length;

  const toggleHabit = (dateKey: string, habitKey: string) => {
    const prevCompleted = getCompletedCount(dateKey);
    const prevStreak = calculateStreak();

    setProgress((prev) => {
      const day = prev[dateKey]?.habits || {};
      const newHabits = { ...day, [habitKey]: !day[habitKey] };
      const newState = { ...prev, [dateKey]: { ...prev[dateKey], habits: newHabits } };
      const newCompleted = activeHabits.filter((h) => newState[dateKey]?.habits?.[h.key]).length;
      const total = activeHabits.length;

      if (total > 0 && newCompleted === total && prevCompleted < total) {
        const newStreak = calculateStreak();

        STREAK_MILESTONES.forEach((m) => {
          if (newStreak >= m.days && prevStreak < m.days) {
            setStreakBonus({ days: m.days, xp: m.xpBonus });
            setTimeout(() => setStreakBonus(null), 3000);
          }
        });

        const prevAchievements = achievements.filter((a) => a.unlockedAt);
        const newAchievementIds = unlockedAchievementIds;

        const newlyUnlocked = achievements.filter(
          (a) => newAchievementIds.has(a.id) && !prevAchievements.find((pa) => pa.id === a.id)
        );

        if (newlyUnlocked.length > 0) {
          setNewAchievements(newlyUnlocked);
          setTimeout(() => setNewAchievements([]), 4000);
        }
      }

      return newState;
    });
  };

  const setHours = (dateKey: string, hours: number) => {
    setProgress((prev) => ({
      ...prev,
      [dateKey]: { ...prev[dateKey], habits: prev[dateKey]?.habits || {}, hours },
    }));
  };

  const setNote = (dateKey: string, note: string) => {
    setProgress((prev) => ({
      ...prev,
      [dateKey]: { ...prev[dateKey], habits: prev[dateKey]?.habits || {}, note },
    }));
  };

  const getDayClass = (dateKey: string) => {
    const completed = getCompletedCount(dateKey);
    const total = activeHabits.length;
    if (total === 0) return 'border-gray-200 bg-white/80';
    if (completed === total && total > 0) return 'border-green-500 bg-green-50/90 shadow-md shadow-green-200/50 scale-[1.01]';
    if (completed > 0) return 'border-amber-400 bg-amber-50/90';
    return 'border-gray-200 bg-white/80';
  };

  const groupedMonths: Record<string, Date[]> = {};
  dates.forEach((date) => {
    const monthKey = `${date.getFullYear()}-${date.getMonth()}`;
    if (!groupedMonths[monthKey]) groupedMonths[monthKey] = [];
    groupedMonths[monthKey].push(date);
  });

  const monthNames = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  const visibleMonthKey = `${today.getFullYear()}-${selectedMonth}`;
  const visibleMonthDates = groupedMonths[visibleMonthKey] || [];

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (monthDropdownRef.current && !monthDropdownRef.current.contains(e.target as Node)) {
        setMonthDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const progressToNextLevel = xp % 15;
  const progressPercent = (progressToNextLevel / 15) * 100;

  return (
    <div className="min-h-screen relative overflow-x-hidden" style={{ background: 'linear-gradient(135deg, #0f0f0f 0%, #1a1a2e 40%, #16213e 70%, #0f0f23 100%)' }}>
      {/* Musashi background — more visible */}
      <div
        className="fixed right-0 bottom-0 w-[480px] h-[640px] pointer-events-none select-none z-0"
        style={{
          backgroundImage: 'url(/images/musashi.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'top center',
          maskImage: 'linear-gradient(to left, rgba(0,0,0,0.42) 0%, rgba(0,0,0,0.28) 50%, transparent 100%), linear-gradient(to top, rgba(0,0,0,0.45) 0%, transparent 35%)',
          WebkitMaskImage: 'linear-gradient(to left, rgba(0,0,0,0.42) 0%, rgba(0,0,0,0.28) 50%, transparent 100%), linear-gradient(to top, rgba(0,0,0,0.45) 0%, transparent 35%)',
          filter: 'contrast(1.15) saturate(0.9)',
          opacity: 0.38,
          mixBlendMode: 'screen',
        }}
      />

      {/* Japanese red sun motif */}
      <div
        className="fixed top-[8%] right-[12%] w-32 h-32 rounded-full pointer-events-none z-0"
        style={{
          background: 'radial-gradient(circle, rgba(220,38,38,0.12) 0%, rgba(220,38,38,0.04) 70%, transparent 100%)',
          filter: 'blur(1px)',
        }}
      />

      {/* Calligraphy-style top/bottom borders */}
      <div className="fixed top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-600/30 to-transparent z-10" />
      <div className="fixed bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-600/30 to-transparent z-10" />

      {/* Animated glow orbs */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-80px] left-[10%] w-[400px] h-[400px] rounded-full opacity-10 blur-3xl animate-pulse" style={{ background: 'radial-gradient(circle, #3b82f6 0%, transparent 70%)', animationDuration: '4s' }} />
        <div className="absolute top-[30%] right-[5%] w-[300px] h-[300px] rounded-full opacity-8 blur-3xl animate-pulse" style={{ background: 'radial-gradient(circle, #06b6d4 0%, transparent 70%)', animationDuration: '6s', animationDelay: '1s' }} />
        <div className="absolute bottom-[10%] left-[20%] w-[350px] h-[350px] rounded-full opacity-6 blur-3xl animate-pulse" style={{ background: 'radial-gradient(circle, #1d4ed8 0%, transparent 70%)', animationDuration: '8s', animationDelay: '2s' }} />
      </div>

      {/* Modals */}
      {showHabits && (
        <HabitsModal habits={habits} onChange={setHabits} onClose={() => setShowHabits(false)} />
      )}
      {showDeadlines && (
        <DeadlinesModal deadlines={deadlines} onChange={setDeadlines} onClose={() => setShowDeadlines(false)} />
      )}
      {showAchievements && (
        <AchievementsModal
          achievements={achievements}
          streakMilestones={streakMilestones}
          stats={{ totalXP: xp, level, currentStreak: streak, longestStreak, totalTasksCompleted: totalTasks, perfectDays }}
          onClose={() => setShowAchievements(false)}
        />
      )}
      {showHistory && (
        <StreakHistoryModal progress={progress} onClose={() => setShowHistory(false)} />
      )}

      {/* Toast: streak bonus */}
      {streakBonus && (
        <div className="fixed top-8 left-1/2 -translate-x-1/2 z-50 animate-bounce">
          <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3">
            <Flame size={24} className="animate-pulse" />
            <div>
              <div className="font-bold">{streakBonus.days} дней серии!</div>
              <div className="text-sm opacity-90">+{streakBonus.xp} XP бонус</div>
            </div>
          </div>
        </div>
      )}

      {/* Toast: new achievements */}
      {newAchievements.length > 0 && (
        <div className="fixed top-8 right-8 z-50 space-y-2">
          {newAchievements.map((achievement) => (
            <div
              key={achievement.id}
              className="bg-gradient-to-r from-amber-400 to-orange-500 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-pulse"
            >
              <Star size={24} />
              <div>
                <div className="font-bold">{achievement.name}</div>
                <div className="text-xs opacity-90">{achievement.description}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        {/* Header card */}
        <div className="mb-8 rounded-3xl shadow-2xl p-6 border border-white/10 backdrop-blur-md" style={{ background: 'rgba(255,255,255,0.06)' }}>
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                {/* Profile avatar with achievement status */}
                <div className="relative group flex-shrink-0">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center border-2 border-white/20 overflow-hidden"
                    style={{ background: `linear-gradient(135deg, hsl(${(level * 25) % 360}, 60%, 35%), hsl(${(level * 25 + 40) % 360}, 60%, 25%))` }}
                  >
                    <User size={28} className="text-white/90" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 border-2 border-gray-900 flex items-center justify-center text-[10px] font-bold text-white shadow-lg">
                    {level}
                  </div>
                  {/* Tooltip on hover */}
                  <div className="absolute top-full left-0 mt-2 hidden group-hover:block z-20 w-56 bg-gray-900/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-3">
                    <div className="text-white font-bold text-sm mb-2">Профиль</div>
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between text-white/70"><span>Уровень</span><span className="text-cyan-300 font-bold">{level}</span></div>
                      <div className="flex justify-between text-white/70"><span>XP</span><span className="text-blue-300 font-bold">{xp}</span></div>
                      <div className="flex justify-between text-white/70"><span>Серия</span><span className="text-orange-300 font-bold">{streak} дней</span></div>
                      <div className="flex justify-between text-white/70"><span>Достижения</span><span className="text-amber-300 font-bold">{totalAchievements}/{ALL_ACHIEVEMENTS.length}</span></div>
                      <div className="flex justify-between text-white/70"><span>Идеальных дней</span><span className="text-green-300 font-bold">{perfectDays}</span></div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-white/10">
                      <div className="flex justify-between text-[10px] text-white/50 mb-1">
                        <span>До уровня {level + 1}</span>
                        <span>{progressToNextLevel}/15 XP</span>
                      </div>
                      <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${progressPercent}%`, background: 'linear-gradient(90deg, #3b82f6, #06b6d4)' }} />
                      </div>
                    </div>
                  </div>
                </div>

                <h1 className="text-4xl font-bold text-white tracking-tight">Daily Progress Tracker</h1>
                <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-orange-500/20 border border-orange-500/40 text-orange-300 font-bold text-sm backdrop-blur">
                  <Flame size={16} />
                  {streak}
                </div>
                {totalAchievements > 0 && (
                  <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-sm backdrop-blur">
                    <Trophy size={16} />
                    {totalAchievements}
                  </div>
                )}
              </div>
              <p className="text-white/50 text-base">Закрывай каждый день все активные задачи.</p>
              <p className="text-white/20 text-xs mt-1" style={{ fontFamily: 'serif' }}>修羅の道 — Путь воина</p>

              <div className="mt-4 max-w-md">
                <div className="flex justify-between text-sm text-white/60 mb-1.5">
                  <span className="font-semibold text-white/80">Уровень {level}</span>
                  <span>{progressToNextLevel}/15 XP</span>
                </div>
                <div className="h-2.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${progressPercent}%`, background: 'linear-gradient(90deg, #3b82f6, #06b6d4)' }}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-2 flex-shrink-0 flex-wrap">
              <button
                onClick={() => setShowHabits(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-blue-400/30 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 font-semibold text-sm transition-all hover:scale-[1.03] active:scale-[0.97] backdrop-blur"
              >
                <ListTodo size={16} />Задачи
              </button>
              <button
                onClick={() => setShowDeadlines(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-red-400/30 bg-red-500/10 hover:bg-red-500/20 text-red-300 font-semibold text-sm transition-all hover:scale-[1.03] active:scale-[0.97] backdrop-blur"
              >
                <Flag size={16} />Дедлайны
              </button>
              <button
                onClick={() => setShowAchievements(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-amber-400/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-semibold text-sm transition-all hover:scale-[1.03] active:scale-[0.97] backdrop-blur"
              >
                <Trophy size={16} />Достижения
              </button>
              <button
                onClick={() => setShowHistory(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-cyan-400/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-semibold text-sm transition-all hover:scale-[1.03] active:scale-[0.97] backdrop-blur"
              >
                <History size={16} />История
              </button>
              <button
                onClick={onSignOut}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 text-white/50 hover:text-white/80 font-semibold text-sm transition-all hover:scale-[1.03] active:scale-[0.97] backdrop-blur"
              >
                <LogOut size={16} />
              </button>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mt-5">
            {[
              { label: 'XP', value: xp, color: 'text-blue-300' },
              { label: 'Уровень', value: level, color: 'text-cyan-300' },
              { label: 'Серия', value: streak, color: 'text-orange-400' },
              { label: 'Лучшая', value: longestStreak, color: 'text-white/80', hidden: true },
              { label: 'Идеал', value: perfectDays, color: 'text-green-400', hidden: true },
            ].map((stat) => (
              <div
                key={stat.label}
                className={`rounded-2xl p-4 border border-white/10 text-center backdrop-blur ${stat.hidden ? 'hidden sm:block' : ''}`}
                style={{ background: 'rgba(255,255,255,0.05)' }}
              >
                <div className="text-[11px] text-white/40 mb-1 font-medium uppercase tracking-wide">{stat.label}</div>
                <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
              </div>
            ))}
          </div>

          {/* Habit chips */}
          {activeHabits.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {activeHabits.map((h) => (
                <div
                  key={h.key}
                  className="group relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-white/60 text-xs font-medium cursor-default hover:bg-white/10 transition-colors"
                >
                  {h.label}
                  {h.reason && (
                    <div className="absolute bottom-full left-0 mb-2 hidden group-hover:block z-10 w-48 bg-gray-900 text-white text-xs rounded-xl p-2.5 shadow-xl border border-white/10">
                      {h.reason}
                      <div className="absolute top-full left-4 border-4 border-transparent border-t-gray-900" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Status bar */}
        <div className="rounded-2xl border border-white/10 shadow-lg p-4 mb-8 backdrop-blur-md" style={{ background: 'rgba(255,255,255,0.05)' }}>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(135deg, rgba(6,182,212,0.2), rgba(59,130,246,0.2))', border: '1px solid rgba(6,182,212,0.3)' }}>
              <Sparkles size={20} className="text-cyan-400" />
            </div>
            <div className="flex-1">
              <label className="text-[11px] font-semibold text-white/40 uppercase tracking-wide">Текущий статус</label>
              <input
                type="text"
                value={statusText}
                onChange={(e) => setStatusText(e.target.value)}
                placeholder="Чем вы занимаетесь прямо сейчас?"
                className="mt-1 w-full text-sm text-white/80 bg-transparent border-0 border-b border-transparent hover:border-white/20 focus:border-cyan-500 focus:outline-none transition-colors pb-1 placeholder:text-white/20"
              />
            </div>
          </div>
        </div>

        {/* Month selector */}
        <div className="flex items-center justify-between mb-6">
          <div className="relative" ref={monthDropdownRef}>
            <button
              onClick={() => setMonthDropdownOpen(!monthDropdownOpen)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 text-white font-bold text-lg transition-all backdrop-blur"
            >
              {monthNames[selectedMonth]}
              <ChevronDown size={20} className={`text-white/50 transition-transform ${monthDropdownOpen ? 'rotate-180' : ''}`} />
            </button>
            {monthDropdownOpen && (
              <div className="absolute top-full left-0 mt-2 w-48 bg-gray-900/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-2 z-30 grid grid-cols-2 gap-1">
                {monthNames.map((name, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setSelectedMonth(idx); setMonthDropdownOpen(false); }}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all text-left ${
                      idx === selectedMonth
                        ? 'bg-blue-500/30 text-blue-200 border border-blue-400/30'
                        : 'text-white/60 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    {name}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedMonth(m => Math.max(0, m - 1))}
              disabled={selectedMonth === 0}
              className="px-3 py-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-white/70 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-all text-sm font-medium"
            >
              ←
            </button>
            <button
              onClick={() => setSelectedMonth(today.getMonth())}
              className="px-4 py-2.5 rounded-xl border border-cyan-400/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-medium text-sm transition-all"
            >
              Сегодня
            </button>
            <button
              onClick={() => setSelectedMonth(m => Math.min(11, m + 1))}
              disabled={selectedMonth === 11}
              className="px-3 py-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-white/70 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-all text-sm font-medium"
            >
              →
            </button>
          </div>
        </div>

        {/* Calendar */}
        <div>
          <div key={visibleMonthKey}>
            <h2 className="text-xl font-bold mb-5 capitalize text-white/70 tracking-wide flex items-center gap-3">
              <span className="w-8 h-px bg-white/20 block" />
              {monthNames[selectedMonth]} {today.getFullYear()}
              <span className="flex-1 h-px bg-white/10 block" />
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {visibleMonthDates.map((date) => {
                    const dateKey = formatDateKey(date);
                    const completed = getCompletedCount(dateKey);
                    const total = activeHabits.length;
                    const isDeadline = deadlineSet.has(dateKey);
                    const deadlineLabel = deadlineMap.get(dateKey);
                    const isToday = dateKey === todayKey;
                    const isPerfectDay = total > 0 && completed === total;

                    return (
                      <div
                        key={dateKey}
                        className={`rounded-2xl border-2 p-4 transition-all duration-200 backdrop-blur-sm ${getDayClass(dateKey)} ${isToday ? 'ring-2 ring-blue-400/60 ring-offset-2 ring-offset-transparent' : ''}`}
                        style={isPerfectDay ? { boxShadow: '0 0 20px rgba(34,197,94,0.15)' } : undefined}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xl font-bold text-gray-900">{date.getDate()}</span>
                              {isDeadline && (
                                <div className="relative group">
                                  <div className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm shadow-red-300 animate-pulse" />
                                  {deadlineLabel && (
                                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-10 whitespace-nowrap bg-gray-900 text-white text-xs rounded-lg px-2.5 py-1.5 shadow-xl">
                                      {deadlineLabel}
                                      <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-gray-900" />
                                    </div>
                                  )}
                                </div>
                              )}
                              {isPerfectDay && !isToday && (
                                <Sparkles size={14} className="text-amber-500" />
                              )}
                              {isToday && (
                                <span className="text-xs font-semibold text-blue-500">сегодня</span>
                              )}
                            </div>
                            <div className="text-xs text-gray-400 mt-0.5">
                              {date.toLocaleDateString('ru-RU', { weekday: 'short' })}
                            </div>
                          </div>
                          <div className="text-sm font-semibold text-gray-500">{completed}/{total}</div>
                        </div>

                        <div className="space-y-1.5">
                          {activeHabits.map((habit) => {
                            const checked = progress[dateKey]?.habits?.[habit.key];
                            return (
                              <button
                                key={habit.key}
                                onClick={() => toggleHabit(dateKey, habit.key)}
                                title={habit.reason || undefined}
                                className={`w-full rounded-xl border px-3 py-2 text-left transition-all duration-150 font-medium text-xs ${
                                  checked
                                    ? 'bg-green-500 text-white border-green-500 shadow-sm shadow-green-200/50'
                                    : 'bg-white hover:bg-gray-50 border-gray-200 text-gray-700'
                                }`}
                              >
                                <span className="mr-1">{checked ? '✅' : '⬜'}</span>
                                {habit.label}
                              </button>
                            );
                          })}
                          {activeHabits.length === 0 && (
                            <p className="text-xs text-gray-400 text-center py-2">Нет задач</p>
                          )}
                        </div>

                        <div className="mt-3 pt-3 border-t border-gray-100">
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <Clock size={12} className="text-gray-400" />
                            <span className="text-[11px] font-medium text-gray-500">Часы работы</span>
                            <span className="text-[11px] font-bold text-gray-700 ml-auto">{progress[dateKey]?.hours ?? 0}ч</span>
                          </div>
                          <div className="flex gap-0.5 flex-wrap">
                            {[0,1,2,3,4,5,6,7,8,9,10,11,12].map((h) => {
                              const selected = (progress[dateKey]?.hours ?? 0) === h;
                              return (
                                <button
                                  key={h}
                                  onClick={() => setHours(dateKey, h)}
                                  className={`w-6 h-6 rounded-md text-[10px] font-bold transition-all ${
                                    selected
                                      ? 'bg-cyan-500 text-white shadow-sm scale-110'
                                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                                  }`}
                                >
                                  {h}
                                </button>
                              );
                            })}
                          </div>

                          <textarea
                            value={progress[dateKey]?.note ?? ''}
                            onChange={(e) => setNote(dateKey, e.target.value)}
                            placeholder="Что вы сделали сегодня?"
                            className="mt-3 w-full text-xs text-gray-700 bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-2 resize-none focus:outline-none focus:ring-1 focus:ring-cyan-400 focus:border-cyan-400 transition-all"
                            rows={2}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
          </div>
      </div>
    </div>
  );
}
