import { useState, FormEvent } from 'react';
import { Lock, User } from 'lucide-react';

interface LoginScreenProps {
  onSignIn: (username: string, password: string) => Promise<{ error: string | null }>;
}

export default function LoginScreen({ onSignIn }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error: signInError } = await onSignIn(username, password);
    if (signInError) {
      setError('Неверный логин или пароль');
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden"
      style={{ background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 40%, #16161d 70%, #0f0f0f 100%)' }}
    >
      {/* Musashi background — prominent on login */}
      <div
        className="absolute right-0 top-0 bottom-0 w-[45%] pointer-events-none"
        style={{
          backgroundImage: 'url(/images/musashi.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center top',
          maskImage: 'linear-gradient(to left, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.25) 60%, transparent 100%)',
          WebkitMaskImage: 'linear-gradient(to left, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.25) 60%, transparent 100%)',
          filter: 'contrast(1.15) saturate(0.85)',
        }}
      />

      {/* Red sun circle — Japanese motif */}
      <div
        className="absolute top-[15%] left-[8%] w-40 h-40 rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(220,38,38,0.35) 0%, rgba(220,38,38,0.08) 70%, transparent 100%)',
          filter: 'blur(2px)',
        }}
      />

      {/* Calligraphy-style decorative lines */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-600/40 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-600/40 to-transparent" />

      <div className="relative z-10 w-full max-w-md">
        <div
          className="rounded-3xl shadow-2xl p-8 border border-white/10 backdrop-blur-xl"
          style={{ background: 'rgba(15,15,20,0.85)' }}
        >
          {/* Japanese-style mon (crest) */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center border-2 border-red-500/40"
                style={{ background: 'radial-gradient(circle, rgba(220,38,38,0.15) 0%, transparent 70%)' }}
              >
                <span className="text-3xl font-bold text-red-400" style={{ fontFamily: 'serif' }}>
                  道
                </span>
              </div>
            </div>
          </div>

          <h1 className="text-2xl font-bold text-white text-center mb-1 tracking-wide">
            Daily Progress
          </h1>
          <p className="text-white/40 text-center text-sm mb-8">
            Войдите, чтобы продолжить путь
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wide mb-1.5 block">
                Логин
              </label>
              <div className="relative">
                <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  autoComplete="username"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/20 focus:outline-none focus:border-red-500/50 focus:bg-white/10 transition-all"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wide mb-1.5 block">
                Пароль
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/20 focus:outline-none focus:border-red-500/50 focus:bg-white/10 transition-all"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded-xl py-2 px-3">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-bold text-white transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg, #b91c1c 0%, #dc2626 50%, #991b1b 100%)' }}
            >
              {loading ? 'Вход...' : 'Войти'}
            </button>
          </form>
        </div>

        <p className="text-center text-white/20 text-xs mt-6">
          強く、正しく、美しく
        </p>
      </div>
    </div>
  );
}
