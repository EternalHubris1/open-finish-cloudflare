import { X, Trophy, Flame, Star, Target, Zap, Crown, Medal, Lock } from 'lucide-react';
import { Achievement, StreakMilestone } from './types';

interface Props {
  achievements: Achievement[];
  streakMilestones: StreakMilestone[];
  stats: {
    totalXP: number;
    level: number;
    currentStreak: number;
    longestStreak: number;
    totalTasksCompleted: number;
    perfectDays: number;
  };
  onClose: () => void;
}

const iconMap: Record<string, React.ReactNode> = {
  trophy: <Trophy size={24} />,
  flame: <Flame size={24} />,
  star: <Star size={24} />,
  target: <Target size={24} />,
  zap: <Zap size={24} />,
  crown: <Crown size={24} />,
  medal: <Medal size={24} />,
};

export default function AchievementsModal({ achievements, streakMilestones, stats, onClose }: Props) {
  const lockedAchievements = achievements.filter((a) => !a.unlockedAt);
  const unlockedAchievements = achievements.filter((a) => a.unlockedAt);

  const progressToNextLevel = stats.totalXP % 15;
  const progressPercent = (progressToNextLevel / 15) * 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm overflow-y-auto py-8">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl mx-4 overflow-hidden">
        <div className="relative bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 px-6 py-8 overflow-hidden">
          {/* Musashi background */}
          <div
            className="absolute right-0 top-0 bottom-0 w-48 opacity-25 pointer-events-none"
            style={{
              backgroundImage: 'url(/images/musashi.jpg)',
              backgroundSize: 'cover',
              backgroundPosition: 'top center',
              maskImage: 'linear-gradient(to left, rgba(0,0,0,1) 0%, transparent 100%)',
              WebkitMaskImage: 'linear-gradient(to left, rgba(0,0,0,1) 0%, transparent 100%)',
            }}
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl bg-white/20 hover:bg-white/30 transition-colors backdrop-blur z-10"
          >
            <X size={20} className="text-white" />
          </button>
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-20 h-20 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center border-2 border-white/30 overflow-hidden">
              <div
                className="w-full h-full"
                style={{
                  backgroundImage: 'url(/images/musashi.jpg)',
                  backgroundSize: 'cover',
                  backgroundPosition: 'top center',
                }}
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white">Достижения</h2>
              <p className="text-white/80 mt-1">Разблокировано: {unlockedAchievements.length}/{achievements.length}</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-5 border border-gray-200">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Flame size={20} className="text-orange-500" />
              Прогресс уровня
            </h3>
            <div className="relative">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span className="font-semibold">Уровень {stats.level}</span>
                <span>{progressToNextLevel}/15 XP до уровня {stats.level + 1}</span>
              </div>
              <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Star size={20} className="text-amber-500" />
              Огненные вехи
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {streakMilestones.map((milestone) => (
                <div
                  key={milestone.days}
                  className={`rounded-xl p-3 text-center transition-all ${
                    milestone.unlocked
                      ? 'bg-gradient-to-br from-orange-400 to-red-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-400'
                  }`}
                >
                  <div className="text-2xl font-bold">{milestone.days}</div>
                  <div className="text-xs font-medium opacity-80">{milestone.reward}</div>
                  {milestone.unlocked && <div className="text-[10px] mt-1 opacity-70">+{milestone.xpBonus} XP</div>}
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Trophy size={20} className="text-yellow-500" />
              Разблокированные ({unlockedAchievements.length})
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {unlockedAchievements.length === 0 ? (
                <div className="col-span-2 text-center py-6 text-gray-400 text-sm">
                  Пока нет достижений. Продолжай учиться!
                </div>
              ) : (
                unlockedAchievements.map((achievement) => (
                  <div
                    key={achievement.id}
                    className="flex items-center gap-3 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-3 border border-amber-200"
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white flex-shrink-0">
                      {iconMap[achievement.icon] || <Trophy size={24} />}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">{achievement.name}</div>
                      <div className="text-xs text-gray-500">{achievement.description}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Lock size={20} className="text-gray-400" />
              Заблокированные ({lockedAchievements.length})
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {lockedAchievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className="flex items-center gap-3 bg-gray-50 rounded-xl p-3 border border-gray-200 opacity-60"
                >
                  <div className="w-12 h-12 rounded-xl bg-gray-200 flex items-center justify-center text-gray-400 flex-shrink-0">
                    <Lock size={20} />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-700">{achievement.name}</div>
                    <div className="text-xs text-gray-500">{achievement.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{stats.totalTasksCompleted}</div>
              <div className="text-xs text-gray-500 mt-1">Задач выполнено</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{stats.perfectDays}</div>
              <div className="text-xs text-gray-500 mt-1">Идеальных дней</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">{stats.longestStreak}</div>
              <div className="text-xs text-gray-500 mt-1">Лучшая серия</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-gray-900 text-white font-semibold hover:bg-gray-800 transition-colors"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
}
