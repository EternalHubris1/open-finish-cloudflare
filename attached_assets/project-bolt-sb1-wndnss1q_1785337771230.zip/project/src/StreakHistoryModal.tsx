import { X, Clock, TrendingUp, Calendar } from 'lucide-react';
import { Progress } from './types';

interface Props {
  progress: Progress;
  onClose: () => void;
}

function getHourColor(hours: number): { bar: string; text: string; bg: string } {
  if (hours <= 0) return { bar: 'bg-gray-200', text: 'text-gray-400', bg: 'bg-gray-50' };
  if (hours <= 2) return { bar: 'bg-gradient-to-r from-red-400 to-red-500', text: 'text-red-600', bg: 'bg-red-50' };
  if (hours <= 3) return { bar: 'bg-gradient-to-r from-amber-400 to-yellow-500', text: 'text-amber-600', bg: 'bg-amber-50' };
  if (hours <= 6) return { bar: 'bg-gradient-to-r from-green-400 to-emerald-500', text: 'text-green-600', bg: 'bg-green-50' };
  if (hours <= 8) return { bar: 'bg-gradient-to-r from-purple-400 to-violet-500', text: 'text-purple-600', bg: 'bg-purple-50' };
  return { bar: 'bg-gradient-to-r from-violet-500 to-fuchsia-600', text: 'text-fuchsia-600', bg: 'bg-fuchsia-50' };
}

const LEGEND = [
  { range: '0-2ч', color: 'bg-red-500', label: 'Мало' },
  { range: '3ч', color: 'bg-amber-500', label: 'Норм' },
  { range: '4-6ч', color: 'bg-green-500', label: 'Идеально' },
  { range: '7-8ч', color: 'bg-purple-500', label: 'Много' },
  { range: '9+ч', color: 'bg-fuchsia-600', label: 'Переработка' },
];

export default function StreakHistoryModal({ progress, onClose }: Props) {
  const entries = Object.entries(progress)
    .filter(([, day]) => typeof day.hours === 'number')
    .sort((a, b) => b[0].localeCompare(a[0]));

  const totalHours = entries.reduce((sum, [, day]) => sum + (day.hours || 0), 0);
  const activeDays = entries.filter(([, day]) => (day.hours || 0) > 0).length;
  const avgHours = activeDays > 0 ? (totalHours / activeDays).toFixed(1) : '0';
  const maxHours = entries.reduce((max, [, day]) => Math.max(max, day.hours || 0), 0);

  const formatDate = (dateKey: string) => {
    const d = new Date(dateKey);
    return d.toLocaleDateString('ru-RU', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
    });
  };

  const getBarWidth = (hours: number) => {
    if (maxHours === 0) return 0;
    return Math.max((hours / maxHours) * 100, hours > 0 ? 4 : 0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm overflow-y-auto py-8">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl mx-4 overflow-hidden">
        <div className="relative bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 px-6 py-8 overflow-hidden">
          {/* Musashi background */}
          <div
            className="absolute right-0 top-0 bottom-0 w-48 opacity-20 pointer-events-none"
            style={{
              backgroundImage: 'url(/images/musashi.jpg)',
              backgroundSize: 'cover',
              backgroundPosition: 'top center',
              maskImage: 'linear-gradient(to left, rgba(0,0,0,1) 0%, transparent 100%)',
              WebkitMaskImage: 'linear-gradient(to left, rgba(0,0,0,1) 0%, transparent 100%)',
            }}
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl bg-white/20 hover:bg-white/30 transition-colors backdrop-blur z-10"
          >
            <X size={20} className="text-white" />
          </button>
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-20 h-20 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center border-2 border-white/30 overflow-hidden">
              <div
                className="w-full h-full"
                style={{
                  backgroundImage: 'url(/images/musashi.jpg)',
                  backgroundSize: 'cover',
                  backgroundPosition: 'top center',
                }}
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white">История часов</h2>
              <p className="text-white/80 mt-1">Сколько часов вы работали каждый день</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="rounded-2xl bg-blue-50 p-4 border border-blue-100 text-center">
              <Clock size={20} className="text-blue-500 mx-auto mb-1" />
              <div className="text-2xl font-bold text-gray-900">{totalHours}ч</div>
              <div className="text-xs text-gray-500 mt-0.5">Всего часов</div>
            </div>
            <div className="rounded-2xl bg-green-50 p-4 border border-green-100 text-center">
              <Calendar size={20} className="text-green-500 mx-auto mb-1" />
              <div className="text-2xl font-bold text-gray-900">{activeDays}</div>
              <div className="text-xs text-gray-500 mt-0.5">Активных дней</div>
            </div>
            <div className="rounded-2xl bg-amber-50 p-4 border border-amber-100 text-center">
              <TrendingUp size={20} className="text-amber-500 mx-auto mb-1" />
              <div className="text-2xl font-bold text-gray-900">{avgHours}ч</div>
              <div className="text-xs text-gray-500 mt-0.5">В среднем/день</div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Calendar size={20} className="text-blue-500" />
              По дням
            </h3>
            {entries.length === 0 ? (
              <div className="text-center py-10 text-gray-400">
                <Clock size={32} className="mx-auto mb-2 opacity-40" />
                <p className="text-sm">Пока нет данных. Отметьте часы в календаре!</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[40vh] overflow-y-auto pr-1">
                {entries.map(([dateKey, day]) => {
                  const hours = day.hours || 0;
                  const colors = getHourColor(hours);
                  return (
                    <div
                      key={dateKey}
                      className={`flex items-center gap-3 rounded-xl border border-gray-200 p-3 ${colors.bg} transition-colors`}
                    >
                      <div className="text-sm font-medium text-gray-600 w-28 flex-shrink-0">
                        {formatDate(dateKey)}
                      </div>
                      <div className="flex-1 h-7 bg-gray-100 rounded-lg overflow-hidden relative">
                        <div
                          className={`h-full ${colors.bar} rounded-lg transition-all duration-500 flex items-center justify-end pr-2`}
                          style={{ width: `${getBarWidth(hours)}%` }}
                        >
                          {hours > 0 && (
                            <span className="text-[10px] font-bold text-white/90">{hours}ч</span>
                          )}
                        </div>
                      </div>
                      <div className={`text-sm font-bold w-8 text-right flex-shrink-0 ${colors.text}`}>
                        {hours}ч
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-gray-200">
            <div className="text-xs text-gray-500 font-medium mb-2">Шкала часов:</div>
            <div className="flex items-center gap-2 flex-wrap">
              {LEGEND.map((item) => (
                <div key={item.range} className="flex items-center gap-1.5">
                  <div className={`w-4 h-4 rounded ${item.color}`} />
                  <span className="text-xs text-gray-600 font-medium">
                    {item.range} — {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
