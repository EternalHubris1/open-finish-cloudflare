export interface Habit {
  key: string;
  label: string;
  reason: string;
  enabled: boolean;
}

export interface Deadline {
  date: string;
  label: string;
}

export interface DayProgress {
  habits: { [habitKey: string]: boolean };
  hours?: number;
  note?: string;
}

export interface Progress {
  [dateKey: string]: DayProgress;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'streak' | 'xp' | 'level' | 'special';
  requirement: number;
  unlockedAt?: string;
}

export interface GameStats {
  totalXP: number;
  level: number;
  currentStreak: number;
  longestStreak: number;
  totalTasksCompleted: number;
  perfectDays: number;
  achievements: string[];
  lastActiveDate: string;
}

export interface StreakMilestone {
  days: number;
  reward: string;
  xpBonus: number;
  unlocked: boolean;
}
