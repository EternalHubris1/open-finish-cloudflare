import { X, Plus, Trash2, Flag } from 'lucide-react';
import { Deadline } from './types';

interface Props {
  deadlines: Deadline[];
  onChange: (deadlines: Deadline[]) => void;
  onClose: () => void;
}

const today = new Date().toISOString().split('T')[0];

export default function DeadlinesModal({ deadlines, onChange, onClose }: Props) {
  const updateDeadline = (index: number, field: keyof Deadline, value: string) => {
    onChange(deadlines.map((d, i) => (i === index ? { ...d, [field]: value } : d)));
  };

  const addDeadline = () => {
    onChange([...deadlines, { date: today, label: 'Дедлайн' }]);
  };

  const removeDeadline = (index: number) => {
    onChange(deadlines.filter((_, i) => i !== index));
  };

  const sorted = [...deadlines].sort((a, b) => a.date.localeCompare(b.date));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Дедлайны</h2>
            <p className="text-sm text-gray-500 mt-0.5">Отмечаются красной точкой в календаре</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-gray-100 transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-3 max-h-[60vh] overflow-y-auto">
          {sorted.length === 0 && (
            <div className="text-center py-8 text-gray-400">
              <Flag size={32} className="mx-auto mb-2 opacity-40" />
              <p className="text-sm">Нет дедлайнов. Добавьте первый!</p>
            </div>
          )}
          {sorted.map((deadline, index) => {
            const originalIndex = deadlines.indexOf(deadline);
            const isPast = deadline.date < today;
            return (
              <div
                key={`${deadline.date}-${index}`}
                className={`rounded-2xl border-2 p-4 flex items-center gap-3 transition-all ${
                  isPast ? 'border-gray-200 bg-gray-50 opacity-60' : 'border-red-200 bg-red-50/50'
                }`}
              >
                <div className={`w-3 h-3 rounded-full flex-shrink-0 ${isPast ? 'bg-gray-400' : 'bg-red-500'}`} />
                <input
                  type="date"
                  value={deadline.date}
                  onChange={(e) => updateDeadline(originalIndex, 'date', e.target.value)}
                  className="text-sm font-mono text-gray-700 bg-transparent border-none outline-none cursor-pointer"
                />
                <input
                  type="text"
                  value={deadline.label}
                  onChange={(e) => updateDeadline(originalIndex, 'label', e.target.value)}
                  className="flex-1 text-sm font-semibold text-gray-800 bg-transparent border-none outline-none"
                  placeholder="Описание дедлайна"
                />
                <button
                  onClick={() => removeDeadline(originalIndex)}
                  className="p-1.5 rounded-lg hover:bg-red-100 transition-colors group flex-shrink-0"
                >
                  <Trash2 size={14} className="text-gray-400 group-hover:text-red-500" />
                </button>
              </div>
            );
          })}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between">
          <button
            onClick={addDeadline}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium text-sm transition-colors"
          >
            <Plus size={16} />
            Добавить дедлайн
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white font-semibold text-sm transition-colors"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}
