import { useEffect, useRef } from 'react';
import { supabase, getProfileId } from './supabaseClient';
import { Habit, Deadline, Progress } from './types';

interface AppStateRow {
  profile_id: string;
  habits: Habit[];
  deadlines: Deadline[];
  progress: Progress;
  status?: string;
  updated_at?: string;
}

interface UseCloudSyncArgs {
  habits: Habit[];
  deadlines: Deadline[];
  progress: Progress;
  status: string;
  setHabits: (h: Habit[]) => void;
  setDeadlines: (d: Deadline[]) => void;
  setProgress: (p: Progress) => void;
  setStatus: (s: string) => void;
  isAuthenticated: boolean;
}

export function useCloudSync({
  habits,
  deadlines,
  progress,
  status,
  setHabits,
  setDeadlines,
  setProgress,
  setStatus,
  isAuthenticated,
}: UseCloudSyncArgs) {
  const profileId = getProfileId();
  const loadedRef = useRef(false);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isFirstSaveRef = useRef(true);

  // Load from cloud once after authentication
  useEffect(() => {
    if (!isAuthenticated) return;
    if (loadedRef.current) return;

    let cancelled = false;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('app_state')
          .select('habits, deadlines, progress, status')
          .eq('profile_id', profileId)
          .maybeSingle();

        if (cancelled) return;

        if (error) {
          console.warn('Cloud load failed:', error.message);
          loadedRef.current = true;
          return;
        }

        if (data) {
          const row = data as AppStateRow;
          if (Array.isArray(row.habits)) setHabits(row.habits);
          if (Array.isArray(row.deadlines)) setDeadlines(row.deadlines);
          if (row.progress && typeof row.progress === 'object') setProgress(row.progress);
          if (typeof row.status === 'string') setStatus(row.status);
        }
      } catch (err) {
        console.warn('Cloud load error:', err);
      } finally {
        if (!cancelled) loadedRef.current = true;
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  // Debounced save — waits 1s after last change before writing
  useEffect(() => {
    if (!isAuthenticated) return;
    if (!loadedRef.current) return;

    // Skip the first save after load (it's just the loaded data echoing back)
    if (isFirstSaveRef.current) {
      isFirstSaveRef.current = false;
      return;
    }

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);

    saveTimerRef.current = setTimeout(async () => {
      try {
        const { error } = await supabase.from('app_state').upsert({
          profile_id: profileId,
          habits,
          deadlines,
          progress,
          status,
          updated_at: new Date().toISOString(),
        });
        if (error) console.warn('Cloud save failed:', error.message);
      } catch (err) {
        console.warn('Cloud save error:', err);
      }
    }, 1000);

    return () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, [profileId, habits, deadlines, progress, status, isAuthenticated]);

  return { profileId };
}
