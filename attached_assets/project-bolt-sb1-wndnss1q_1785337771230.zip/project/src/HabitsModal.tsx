import { X, Plus, Trash2, GripVertical } from 'lucide-react';
import { Habit } from './types';

interface Props {
  habits: Habit[];
  onChange: (habits: Habit[]) => void;
  onClose: () => void;
}

export default function HabitsModal({ habits, onChange, onClose }: Props) {
  const updateHabit = (index: number, field: keyof Habit, value: string | boolean) => {
    const updated = habits.map((h, i) => (i === index ? { ...h, [field]: value } : h));
    onChange(updated);
  };

  const addHabit = () => {
    onChange([
      ...habits,
      { key: `habit-${Date.now()}`, label: 'Новая задача', reason: '', enabled: true },
    ]);
  };

  const removeHabit = (index: number) => {
    onChange(habits.filter((_, i) => i !== index));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Управление задачами</h2>
            <p className="text-sm text-gray-500 mt-0.5">Выберите задачи и укажите причины</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-gray-100 transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-3 max-h-[60vh] overflow-y-auto">
          {habits.map((habit, index) => (
            <div
              key={habit.key}
              className={`rounded-2xl border-2 p-4 transition-all duration-200 ${
                habit.enabled ? 'border-blue-200 bg-blue-50/50' : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-3 mb-3">
                <GripVertical size={16} className="text-gray-300 flex-shrink-0" />
                <input
                  type="text"
                  value={habit.label}
                  onChange={(e) => updateHabit(index, 'label', e.target.value)}
                  className="flex-1 font-semibold text-gray-800 bg-transparent border-none outline-none focus:ring-0 text-sm"
                  placeholder="Название задачи"
                />
                <button
                  onClick={() => updateHabit(index, 'enabled', !habit.enabled)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    habit.enabled
                      ? 'bg-blue-500 text-white hover:bg-blue-600'
                      : 'bg-gray-200 text-gray-500 hover:bg-gray-300'
                  }`}
                >
                  {habit.enabled ? 'Вкл' : 'Выкл'}
                </button>
                <button
                  onClick={() => removeHabit(index)}
                  className="p-1.5 rounded-lg hover:bg-red-100 transition-colors group"
                >
                  <Trash2 size={14} className="text-gray-400 group-hover:text-red-500" />
                </button>
              </div>
              <textarea
                value={habit.reason}
                onChange={(e) => updateHabit(index, 'reason', e.target.value)}
                className="w-full text-xs text-gray-600 bg-white/70 border border-gray-200 rounded-xl px-3 py-2 resize-none outline-none focus:ring-2 focus:ring-blue-300 transition-all"
                rows={2}
                placeholder="Зачем эта задача? Укажите причину..."
              />
            </div>
          ))}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between">
          <button
            onClick={addHabit}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium text-sm transition-colors"
          >
            <Plus size={16} />
            Добавить задачу
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-semibold text-sm transition-colors"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}
